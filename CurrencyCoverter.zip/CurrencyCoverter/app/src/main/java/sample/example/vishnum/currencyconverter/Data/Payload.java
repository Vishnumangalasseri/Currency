package sample.example.vishnum.currencyconverter.Data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Payload {
    @SerializedName("rates")
    @Expose
    private ArrayList<Rate> rates = null;

    public ArrayList<Rate> getRates() {
        return rates;
    }

    public void setRates(ArrayList<Rate> rates) {
        this.rates = rates;

    }
}
