package sample.example.vishnum.currencyconverter;

import android.os.Bundle;

import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;


import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import sample.example.vishnum.currencyconverter.Data.Provider;
import sample.example.vishnum.currencyconverter.Data.Country;
import sample.example.vishnum.currencyconverter.Data.Rate;
import sample.example.vishnum.currencycoverter.R;

public class MainActivity extends AppCompatActivity {

    ArrayList<Country> countryArrayList = new ArrayList<>();

    ArrayList<String> CurrencyCodearrayList = new ArrayList<String>();
    ArrayList<Rate>payloadArrayList = new ArrayList<>();
     Spinner s,p;
    Button calculate_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calculate_btn = findViewById(R.id.calculate_btn);
        calculate_btn.setClickable(false);
        s = (Spinner) findViewById(R.id.fromCurrency);
        p = (Spinner) findViewById(R.id.toCurrency);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        CurrencyCodearrayList.clear();
        Api client = RetrofitClient.getClient().create(Api.class);
        Call<Provider> call = client.getCurrencyData();
        call.enqueue(new Callback<Provider>() {
            @Override
            public void onResponse(Call<Provider> call, Response<Provider> response) {
                if (response != null && response.isSuccessful() && response.body() != null ) {
                    String value  = response.body().toString();
                    payloadArrayList = response.body().getPayload().getRates();
                    for (Rate aRate:payloadArrayList) {
                        CurrencyCodearrayList.add(aRate.getToccy());
                    }
                    setValues(CurrencyCodearrayList);
                    }
            }

            @Override
            public void onFailure(Call<Provider> call, Throwable t) {

            }
        });

     calculate_btn.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {

         }
     });



    }

    private void setValues(ArrayList<String> currencyCodearrayList) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,CurrencyCodearrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);
        p.setAdapter(adapter);
        calculate_btn.setClickable(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showSnack(String msg) {
        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG);
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimaryDark));
        TextView textView = sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.white));
        snackbar.show();
    }

    public boolean validation() {
        boolean valid = true;
        if (s.getSelectedItem().toString().equals(p.getSelectedItem().toString())) {
            showSnack("Countries should be different");
            valid = false;
        }
        return valid;

    }


}
