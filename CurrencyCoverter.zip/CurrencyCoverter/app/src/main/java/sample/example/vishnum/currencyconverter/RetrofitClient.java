package sample.example.vishnum.currencyconverter;

import com.google.gson.GsonBuilder;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

class RetrofitClient {

    private static Retrofit retrofit = null;
    private static String BASE_URL="https://raw.githubusercontent.com/Vishnumangalasseri/Currency/master/";


    public static OkHttpClient getOkHttpClient() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        final OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .readTimeout(120, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .connectTimeout(120, TimeUnit.SECONDS)
                // .cache(null)
                .build();
        return okHttpClient;
    }


    public static Retrofit getClient() {
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create((new GsonBuilder().serializeNulls().create())))
                .client(getOkHttpClient())
                .build();
        return retrofit;
    }
}
