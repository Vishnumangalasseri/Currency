package sample.example.vishnum.currencyconverter.Data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Rate  {

    @SerializedName("svcprovcd")
    @Expose
    private String svcprovcd;
    @SerializedName("ccyname")
    @Expose
    private String ccyname;
    @SerializedName("rate")
    @Expose
    private Float rate;
    @SerializedName("toccy")
    @Expose
    private String toccy;
    @SerializedName("sellrate")
    @Expose
    private Float sellrate;
    @SerializedName("buyrate")
    @Expose
    private Integer buyrate;
    @SerializedName("frmccy")
    @Expose
    private String frmccy;

    public String getSvcprovcd() {
        return svcprovcd;
    }

    public void setSvcprovcd(String svcprovcd) {
        this.svcprovcd = svcprovcd;
    }

    public String getCcyname() {
        return ccyname;
    }

    public void setCcyname(String ccyname) {
        this.ccyname = ccyname;
    }

    public Float getRate() {
        return rate;
    }

    public void setRate(Float rate) {
        this.rate = rate;
    }

    public String getToccy() {
        return toccy;
    }

    public void setToccy(String toccy) {
        this.toccy = toccy;
    }

    public Float getSellrate() {
        return sellrate;
    }

    public void setSellrate(Float sellrate) {
        this.sellrate = sellrate;
    }

    public Integer getBuyrate() {
        return buyrate;
    }

    public void setBuyrate(Integer buyrate) {
        this.buyrate = buyrate;
    }

    public String getFrmccy() {
        return frmccy;
    }

    public void setFrmccy(String frmccy) {
        this.frmccy = frmccy;
    }

}
