package sample.example.vishnum.currencyconverter;

import android.app.Application;

import sample.example.vishnum.currencyconverter.Utils.ConnectivityReceiver;

public class AppClass extends Application{
    private static AppClass mInstance;

    @Override
    public void onCreate() {
        super.onCreate();

        mInstance = this;
    }

    public static synchronized AppClass getInstance() {
        return mInstance;
    }

    public void setConnectivityListener(ConnectivityReceiver.ConnectivityReceiverListener listener) {
        ConnectivityReceiver.connectivityReceiverListener = listener;
    }
}
