package sample.example.vishnum.currencyconverter;

import retrofit2.Call;
import retrofit2.http.GET;
import sample.example.vishnum.currencyconverter.Data.Provider;

public interface Api {
    @GET("data.json")
    Call<Provider> getCurrencyData();
}
